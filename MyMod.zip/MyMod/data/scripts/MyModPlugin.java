package data.scripts;
//different files and APIs necessary for mod to function
import java.awt.Color;
import java.util.List;
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator.StarSystemType;
import com.fs.starfarer.api.impl.campaign.terrain.BaseTiledTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin.MagneticFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
//import com.fs.starfarer.api.fleet.FleetMemberType;



//Create System - ADD CUSTOM DESCRIPTIONS, DESCRIPTIONS.CSV
public class MyModPlugin extends BaseModPlugin {
    @Override
    public void onNewGame() {	
		SectorAPI sector = Global.getSector();
		StarSystemAPI system = sector.createStarSystem("Velostcu");
		PlanetAPI star = system.initStar("velostcu", "star_yellow", 700, -7500, -4500, 500); 
		system.setBackgroundTextureFilename("graphics/mymod/backgrounds/velostcu.jpeg");
		system.getLocation().set(5000, 2500); //system location - near Alpha Site, NE of Hybrasil

// Structures and Gate
		SectorEntityToken buoy = system.addCustomEntity("velostcu_buoy","Velostcu Buoy","nav_buoy","neutral");
		buoy.setCircularOrbitPointingDown(star, 40, 1500, 170);
		SectorEntityToken relay = system.addCustomEntity("velostcu_relay","Velostcu Relay","comm_relay","neutral");
		relay.setCircularOrbitPointingDown(star, 190, 2000, 200);
		SectorEntityToken array = system.addCustomEntity("velostcu_array","Velostcu Array","sensor_array","neutral"); 
		array.setCircularOrbitPointingDown(star, 220, 2050, 130);
		SectorEntityToken velostcu_gate = system.addCustomEntity("velostcu_gate","Velostcu Gate","inactive_gate",null);
		velostcu_gate.setCircularOrbit( star, 120, 8000, 250);
	
//Barrier Asteroids
		system.addAsteroidBelt(star, 90, 7650, 1000, 150, 300, Terrain.ASTEROID_BELT,  "The Barrier");
		system.addRingBand(star, "misc", "rings_ice0", 256f, 2, Color.white, 256f, 7750, 385, null, null);
		system.addRingBand(star, "misc", "rings_ice0", 256f, 1, new Color(230,240,255,255), 256f, 7870, 395, null, null);

// system.addPlanet("id", parent, "Name", "type", initial position in degrees, size in pixels, distance in pixels, orbit speed in days)
// for all planet types, go to planets.json in starsector's main files

//Velotan Planet, I
		PlanetAPI velotan = system.addPlanet("velotan", star, "Velotan", "lava", 45, 120, 1675, 125);
		MarketAPI velotan_market = Global.getFactory().createMarket("velotan_market", velotan.getName(), 0);
		velotan_market.setPlanetConditionMarketOnly(true); 
		velotan_market.addCondition(Conditions.ORE_ULTRARICH);
		velotan_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
		velotan_market.addCondition(Conditions.RUINS_VAST);
		velotan_market.addCondition(Conditions.VERY_HOT);
		velotan_market.addCondition(Conditions.NO_ATMOSPHERE);
		velotan_market.setPrimaryEntity(velotan);
		velotan.setMarket(velotan_market); 
		
//Kane Planet, II
		PlanetAPI kane = system.addPlanet("kane", star, "Kane", "terran", 30, 150, 3000, 210);
		MarketAPI kane_market = Global.getFactory().createMarket("kane_market", kane.getName(), 0);
		kane_market.setPlanetConditionMarketOnly(true); 
		kane_market.addCondition(Conditions.HABITABLE);
		kane_market.addCondition(Conditions.MILD_CLIMATE);
		kane_market.addCondition(Conditions.ORE_ULTRARICH);
		kane_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
		kane_market.addCondition(Conditions.ORGANICS_PLENTIFUL);
		kane_market.addCondition(Conditions.VOLATILES_PLENTIFUL);
		kane_market.addCondition(Conditions.FARMLAND_BOUNTIFUL);
		kane_market.addCondition(Conditions.RUINS_VAST);
		kane_market.setPrimaryEntity(kane);
		kane.setMarket(kane_market); 

//Adds ring system to planet Kane

		system.addRingBand(kane, "misc", "rings_special0", 256f, 1, new Color(225,215,255,200), 128f, 380, 30f, Terrain.RING, "Kane's Band");
		
		// Kane Jump Point

		JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("kane_jump", "Kane Jump-point");
		jumpPoint1.setCircularOrbit(star, 100 - 60, 3500, 210);
		jumpPoint1.setStandardWormholeToHyperspaceVisual();
		system.addEntity(jumpPoint1);

// Noctor Planet, III			
		PlanetAPI noctor = system.addPlanet("noctor", star, "Noctor", "arid", 90, 170, 4200, 225);
		MarketAPI noctor_market = Global.getFactory().createMarket("noctor_market", noctor.getName(), 0);
		noctor_market.setPlanetConditionMarketOnly(true); 
		noctor_market.addCondition(Conditions.HABITABLE);
		noctor_market.addCondition(Conditions.ORE_ULTRARICH);
		noctor_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
		noctor_market.addCondition(Conditions.ORGANICS_PLENTIFUL);
		noctor_market.addCondition(Conditions.VOLATILES_PLENTIFUL);
		noctor_market.addCondition(Conditions.FARMLAND_BOUNTIFUL);
		noctor_market.addCondition(Conditions.EXTREME_WEATHER);
		noctor_market.addCondition(Conditions.RUINS_VAST);
		noctor_market.setPrimaryEntity(noctor);
		noctor.setMarket(noctor_market); 

// Darmyro IV and mirror system
		PlanetAPI darmyro = system.addPlanet("darmyro", star, "Darmyro", "jungle", 200, 200, 5500, 425);
		MarketAPI darmyro_market = Global.getFactory().createMarket("darmyro_market", darmyro.getName(), 0);
		darmyro_market.setPlanetConditionMarketOnly(true); 
		darmyro_market.addCondition(Conditions.HABITABLE);
		darmyro_market.addCondition(Conditions.ORE_ULTRARICH);
		darmyro_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
		darmyro_market.addCondition(Conditions.ORGANICS_PLENTIFUL);
		darmyro_market.addCondition(Conditions.FARMLAND_BOUNTIFUL);
		darmyro_market.addCondition(Conditions.DECIVILIZED);
		darmyro_market.addCondition(Conditions.RUINS_VAST);
		darmyro_market.addCondition(Conditions.SOLAR_ARRAY);
		darmyro_market.setPrimaryEntity(darmyro);
		darmyro.setMarket(darmyro_market); 
		//Notice how this planet has the condition Condition.SOLAR_ARRAY - this is to reflect the fact that I have added five mirrors
		//Five different stellar mirrors added to planet Darmyro
			SectorEntityToken darmyro_mirror1 = system.addCustomEntity("darmyro_mirror1", "Darmyro Stellar Mirror Alpha", "stellar_mirror", null);
			SectorEntityToken darmyro_mirror2 = system.addCustomEntity("darmyro_mirror2", "Darmyro Stellar Mirror Beta", "stellar_mirror", null);	
			SectorEntityToken darmyro_mirror3 = system.addCustomEntity("darmyro_mirror3", "Darmyro Stellar Mirror Gamma", "stellar_mirror", null);
			SectorEntityToken darmyro_mirror4 = system.addCustomEntity("darmyro_mirror4", "Darmyro Stellar Mirror Delta", "stellar_mirror", null);
			SectorEntityToken darmyro_mirror5 = system.addCustomEntity("darmyro_mirror5", "Darmyro Stellar Mirror Epsilon", "stellar_mirror", null);
			darmyro_mirror1.setCircularOrbitPointingDown(system.getEntityById("darmyro"), 200 - 60, 400, 425);
			darmyro_mirror2.setCircularOrbitPointingDown(system.getEntityById("darmyro"), 200 - 30, 400, 425);	
			darmyro_mirror3.setCircularOrbitPointingDown(system.getEntityById("darmyro"), 200 + 0, 400, 425);	
			darmyro_mirror4.setCircularOrbitPointingDown(system.getEntityById("darmyro"), 200 + 30, 400, 425);	
			darmyro_mirror5.setCircularOrbitPointingDown(system.getEntityById("darmyro"), 200 + 60, 400, 425);		
			darmyro_mirror1.setCustomDescriptionId("stellar_mirror");
			darmyro_mirror2.setCustomDescriptionId("stellar_mirror");
			darmyro_mirror3.setCustomDescriptionId("stellar_mirror");
			darmyro_mirror4.setCustomDescriptionId("stellar_mirror");
			darmyro_mirror5.setCustomDescriptionId("stellar_mirror");

//Awkease IVA and Rings

			PlanetAPI awkease = system.addPlanet("awkease", darmyro, "Awkease", "barren-desert", 0, 80, 800, 105);
			MarketAPI awkease_market = Global.getFactory().createMarket("awkease_market", awkease.getName(), 0);
			awkease_market.setPlanetConditionMarketOnly(true); 
			awkease_market.addCondition(Conditions.ORE_RICH);
			awkease_market.addCondition(Conditions.RARE_ORE_SPARSE);
			awkease_market.addCondition(Conditions.ORGANICS_COMMON);
			awkease_market.addCondition(Conditions.VERY_COLD);
			awkease_market.addCondition(Conditions.NO_ATMOSPHERE);
			awkease_market.setPrimaryEntity(awkease);
			awkease.setMarket(awkease_market); 

			system.addRingBand(darmyro, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 1050, 70f, Terrain.RING, "Vesperian Ruins");


		
// Kazutora Ice Giant, V - With Pink glows

		PlanetAPI kazutora = system.addPlanet("kazutora", star, "Kazutora", "ice_giant", 20, 400, 11150, 500);
		kazutora.getSpec().setPlanetColor(new Color(200,255,245,255));
		kazutora.getSpec().setAtmosphereColor(new Color(220,250,240,150));
		kazutora.getSpec().setCloudColor(new Color(220,250,240,200));
		kazutora.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
		kazutora.getSpec().setGlowColor(new Color(255,0,140,230));
		kazutora.getSpec().setUseReverseLightForGlow(true);
		kazutora.applySpecChanges();
		
// Alexiar Moon IVA, Stygia Moon IVB, Rings
			system.addRingBand(kazutora, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 875, 33f, Terrain.RING, null);
			system.addRingBand(kazutora, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 900, 40f, Terrain.RING, null);
			system.addRingBand(kazutora, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1000, 20f, Terrain.RING, null);
			system.addRingBand(kazutora, "misc", "rings_dust0", 256f, 4, Color.white, 256f, 1050, 33f, Terrain.RING, null);
			
			PlanetAPI stygia = system.addPlanet("stygia", kazutora, "Stygia", "terran-eccentric", 200, 150, 2000, 425);
			MarketAPI stygia_market = Global.getFactory().createMarket("stygia_market", stygia.getName(), 0);
			stygia_market.setPlanetConditionMarketOnly(true); 
			stygia_market.addCondition(Conditions.HABITABLE);
			stygia_market.addCondition(Conditions.ORE_ULTRARICH);
			stygia_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
			stygia_market.addCondition(Conditions.ORGANICS_COMMON);
			stygia_market.addCondition(Conditions.FARMLAND_BOUNTIFUL);
			stygia_market.addCondition(Conditions.RUINS_VAST);
			stygia_market.addCondition(Conditions.VERY_COLD);
			stygia_market.setPrimaryEntity(stygia);
			stygia.setMarket(stygia_market); 

			PlanetAPI alexiar = system.addPlanet("alexiar", kazutora, "Alexiar", "tundra", 45, 100, 1250, 75);
			MarketAPI alexiar_market = Global.getFactory().createMarket("alexiar_market", alexiar.getName(), 0);
			alexiar_market.setPlanetConditionMarketOnly(true); 
			alexiar_market.addCondition(Conditions.HABITABLE);
			alexiar_market.addCondition(Conditions.ORE_ULTRARICH);
			alexiar_market.addCondition(Conditions.RARE_ORE_ULTRARICH);
			alexiar_market.addCondition(Conditions.ORGANICS_PLENTIFUL);
			alexiar_market.addCondition(Conditions.RUINS_VAST);
			alexiar_market.addCondition(Conditions.VERY_COLD);
			alexiar_market.setPrimaryEntity(alexiar);
			alexiar.setMarket(alexiar_market); 
			//alexiar.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "volturn"));
			//alexiar.getSpec().setGlowColor(new Color(255,255,255,255));
			alexiar.getSpec().setUseReverseLightForGlow(true);
			alexiar.applySpecChanges();
			//alexiar.setCustomDescriptionId("planet_eochu_bres");
				
	// Name VI - CUSTOM DESCRIPTION NEEDED
		PlanetAPI zahard = system.addPlanet("zahard", star, "Zahard", "gas_giant", 230, 350, 15000, 250);
		//zahard.setCustomDescriptionId("planet_zahard");
		zahard.getSpec().setPlanetColor(new Color(255,225,170,255));
		zahard.getSpec().setAtmosphereColor(new Color(160,110,45,140));
		zahard.getSpec().setCloudColor(new Color(255,164,96,200));
		zahard.getSpec().setTilt(15);
		zahard.applySpecChanges();
			
			system.addAsteroidBelt(zahard, 50, 1100, 128, 40, 80, Terrain.ASTEROID_BELT, "Ring");
			system.addRingBand(zahard, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 1100, 40f);
			system.addRingBand(zahard, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 1120, 50f);
			system.addRingBand(zahard, "misc", "rings_dust0", 256f, 0, Color.white, 256f, 1100, 80f);
			system.addRingBand(zahard, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1800, 70f);
			system.addRingBand(zahard, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1800, 90f);
			system.addRingBand(zahard, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1800, 110f, Terrain.RING, "Dust Ring");
			system.addRingBand(zahard, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 2150, 50f);
			system.addRingBand(zahard, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 2150, 70f);
			system.addRingBand(zahard, "misc", "rings_ice0", 256f, 0, Color.white, 256f, 2150, 80f);
			system.addRingBand(zahard, "misc", "rings_ice0", 256f, 1, Color.white, 256f, 2150, 90f, Terrain.RING, "Cloud Ring");

			PlanetAPI wei = system.addPlanet("wei", zahard, "Wei", "irradiated", 40, 40, 1500, 85);
			MarketAPI wei_market = Global.getFactory().createMarket("wei_market", wei.getName(), 0);
			wei_market.setPlanetConditionMarketOnly(true); 
			wei_market.addCondition(Conditions.ORE_SPARSE);
			wei_market.addCondition(Conditions.EXTREME_WEATHER);
			wei_market.addCondition(Conditions.IRRADIATED);
			wei_market.addCondition(Conditions.LOW_GRAVITY);
			wei_market.addCondition(Conditions.NO_ATMOSPHERE);
			wei_market.setPrimaryEntity(wei);
			wei.setMarket(wei_market); 

		//After Creation, Blocks R-Gen - can be edited to include more random gen
		StarSystemGenerator.addOrbitingEntities(system, star, StarAge.AVERAGE,
			0, 0,// 0 new randomly generated entities
			zahard.getCircularOrbitRadius() + 600, // system size
			system.getPlanets().size(),false);
		system.autogenerateHyperspaceJumpPoints(true, true); // adds two jump points
    }
//This is the part of the code responsible for blocking Hyperspace clouds from spawning near the system
	void cleanup(StarSystemAPI system){
    	HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
		NebulaEditor editor = new NebulaEditor(plugin);        
    	float minRadius = plugin.getTileSize() * 2f;
    	float radius = system.getMaxRadiusInHyperspace();
    	editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
    	editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);	     
//editor.clearArc(system.getLocation().x, system.getLocation().y, 0, system.getMaxRadiusInHyperspace()*1.25f, 0, 360, 0.25f);
    }
}